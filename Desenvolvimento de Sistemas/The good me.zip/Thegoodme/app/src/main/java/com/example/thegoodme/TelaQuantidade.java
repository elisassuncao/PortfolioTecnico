package com.example.thegoodme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class TelaQuantidade extends AppCompatActivity {
    static String tipoVape,tipoNarga,tipoCharuto,tipoCigarro;
    static int qtd;
    ImageView cmpVape, cmpNarga, cmpCigarro, cmpCharuto, imgVape, imgNarga, imgCigarro, imgCharuto,fmcVape, fmcNarga, fmcCigarro, fmcCharuto;
    TextView btMaisVape,btMaisNarga, btMaisCigarro, btMaisCharuto, btMenosVape,
            btMenosNarga, btMenosCigarro, btMenosCharuto, contadorVape,contadorNarga,contadorCigarro,contadorCharuto;
    int contarVape = 0,contarNarga = 0,contarCigarro = 0,contarCharuto = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_quantidade);
        getSupportActionBar().hide();
        imgVape = findViewById(R.id.imgVape);
        imgNarga = findViewById(R.id.imgNarga);
        imgCigarro = findViewById(R.id.imgCigarro);
        imgCharuto = findViewById(R.id.imgCharuto);
        cmpVape =  findViewById(R.id.campoVape);
        cmpNarga = findViewById(R.id.campoNarga);
        cmpCigarro = findViewById(R.id.campoCigarro);
        cmpCharuto = findViewById(R.id.campoCharuto);
        fmcVape = findViewById(R.id.fmcVape);
        fmcNarga = findViewById(R.id.fmcNarga);
        fmcCigarro = findViewById(R.id.fmcCigarro);
        fmcCharuto = findViewById(R.id.fmcCharuto);
        btMaisVape = findViewById(R.id.btMaisVape);
        btMaisNarga = findViewById(R.id.btMaisNarga);
        btMaisCigarro = findViewById(R.id.btMaisCigarro);
        btMaisCharuto = findViewById(R.id.btMaisCharuto);
        btMenosVape = findViewById(R.id.btMenosVape);
        btMenosNarga = findViewById(R.id.btMenosNarga);
        btMenosCigarro = findViewById(R.id.btMenosCigarro);
        btMenosCharuto = findViewById(R.id.btMenosCharuto);
        contadorVape = findViewById(R.id.contadorVape);
        contadorNarga = findViewById(R.id.contadorNarga);
        contadorCigarro = findViewById(R.id.contadorCigarro);
        contadorCharuto = findViewById(R.id.contadorCharuto);
        cmpVape.setVisibility(View.INVISIBLE);
        cmpNarga.setVisibility(View.INVISIBLE);
        cmpCigarro.setVisibility(View.INVISIBLE);
        cmpCharuto.setVisibility(View.INVISIBLE);
        imgVape.setVisibility(View.INVISIBLE);
        imgNarga.setVisibility(View.INVISIBLE);
        imgCigarro.setVisibility(View.INVISIBLE);
        imgCharuto.setVisibility(View.INVISIBLE);
        fmcVape.setVisibility(View.INVISIBLE);
        fmcNarga.setVisibility(View.INVISIBLE);
        fmcCigarro.setVisibility(View.INVISIBLE);
        fmcCharuto.setVisibility(View.INVISIBLE);
         btMaisVape.setVisibility(View.INVISIBLE);
        btMaisNarga.setVisibility(View.INVISIBLE);
        btMaisCigarro.setVisibility(View.INVISIBLE);
        btMaisCharuto.setVisibility(View.INVISIBLE);
        btMenosVape.setVisibility(View.INVISIBLE);
        btMenosNarga.setVisibility(View.INVISIBLE);
        btMenosCigarro.setVisibility(View.INVISIBLE);
        btMenosCharuto.setVisibility(View.INVISIBLE);
        contadorVape.setVisibility(View.INVISIBLE);
        contadorNarga.setVisibility(View.INVISIBLE);
        contadorCigarro.setVisibility(View.INVISIBLE);
        contadorCharuto.setVisibility(View.INVISIBLE);
        montarTela();
    }

    public void proxtelaperfil(View view) {
        TelaPerfil.contarVape = contarVape;
        TelaPerfil.contarNarguile = contarNarga;
        TelaPerfil.contarCharuto = contarCharuto;
        TelaPerfil.contarCigarro = contarCigarro;
        Intent i = new Intent(this, TelaPerfil.class);
        startActivity(i);
    }
    public void clickMaisVape(View view){
            String resultado;
            contarVape += 1;
            resultado = Integer.toString(contarVape);
            contadorVape.setText(resultado);


    }
    public void clickMenosVape(View view){
        String resultado;
        resultado = Integer.toString(contarVape -= 1);
        contadorVape.setText(resultado);


    }
    public void clickMaisNarga(View view){
        String resultado;
        contarNarga += 1;
        resultado = Integer.toString(contarNarga);
        contadorNarga.setText(resultado);


    }
    public void clickMenosNarga(View view){
        String resultado;
        resultado = Integer.toString(contarNarga -= 1);
        contadorNarga.setText(resultado);


    }

    public void clickMaisCigarro(View view){
        String resultado;
        contarCigarro += 1;
        resultado = Integer.toString(contarCigarro);
        contadorCigarro.setText(resultado);



    }
    public void clickMenosCigarro(View view){
        String resultado;
        resultado = Integer.toString(contarCigarro -= 1);
        contadorCigarro.setText(resultado);



    }

    public void clickMaisCharuto(View view){
        String resultado;
        contarCharuto += 1;
        resultado = Integer.toString(contarCharuto);
        contadorCharuto.setText(resultado);



    }
    public void clickMenosCharuto(View view){
        String resultado;
        resultado = Integer.toString(contarCharuto -= 1);
        contadorCharuto.setText(resultado);



    }

    public void montarTela(){
        if (tipoVape != ""){
            cmpVape.setVisibility(View.VISIBLE);
            imgVape.setVisibility(View.VISIBLE);
            fmcVape.setVisibility(View.VISIBLE);
            btMaisVape.setVisibility(View.VISIBLE);
            btMenosVape.setVisibility(View.VISIBLE);
            contadorVape.setVisibility(View.VISIBLE);
        }
        if (tipoNarga != ""){
            cmpNarga.setVisibility(View.VISIBLE);
            imgNarga.setVisibility(View.VISIBLE);
            fmcNarga.setVisibility(View.VISIBLE);
            btMaisNarga.setVisibility(View.VISIBLE);
            btMenosNarga.setVisibility(View.VISIBLE);
            contadorNarga.setVisibility(View.VISIBLE);
        }
        if(tipoCigarro != ""){
            cmpCigarro.setVisibility(View.VISIBLE);
            imgCigarro.setVisibility(View.VISIBLE);
            fmcCigarro.setVisibility(View.VISIBLE);
            btMaisCigarro.setVisibility(View.VISIBLE);
            btMenosCigarro.setVisibility(View.VISIBLE);
            contadorCigarro.setVisibility(View.VISIBLE);
        }
        if(tipoCharuto != ""){
            cmpCharuto.setVisibility(View.VISIBLE);
            imgCharuto.setVisibility(View.VISIBLE);
            fmcCharuto.setVisibility(View.VISIBLE);
            btMaisCharuto.setVisibility(View.VISIBLE);
            btMenosCharuto.setVisibility(View.VISIBLE);
            contadorCharuto.setVisibility(View.VISIBLE);
        }
    }
}