package com.example.thegoodme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

import java.util.ArrayList;

public class TelaNivel extends AppCompatActivity {
    RadioButton rb4,rb3,rb2,rb1;
    int contador = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_nivel);
        getSupportActionBar().hide();
        rb4= findViewById(R.id.rb4);
        rb3 = findViewById(R.id.rb3);
        rb2 = findViewById(R.id.rb2);
        rb1 = findViewById(R.id.rb1);
    }
    public void proxquantidade(View view) {
        try{
            vicio();
        } finally {
            Intent i = new Intent(this, TelaQuantidade.class);
            startActivity(i);
        }
    }
    public void vicio(){
        if(rb4.isChecked()){
            contador = 4;

        }else if(rb3.isChecked()){
            contador = 3;

        }else if(rb2.isChecked()){
            contador = 2;

        } else if(rb1.isChecked()){
            contador = 1;

        }else{
            Toast.makeText(this, "Selecione pelo menos uma carinha", Toast.LENGTH_LONG).show();
        }
        TelaQuantidade.qtd = contador;

    }
}
