package com.example.thegoodme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class TelaCadastro extends AppCompatActivity {
    EditText campoLogin, campoSenha;
    String l,s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro);
        getSupportActionBar().hide();
        campoLogin = findViewById(R.id.Login);
        campoSenha = findViewById(R.id.Senha);

    }

    public void voltarpratelalogin(View view) {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
    public void cadastrar(View view) {
        l = campoLogin.getText().toString();
        s = campoSenha.getText().toString();
        if (l.equals("") && s.equals("")) {
            Toast.makeText(this, "Preencha todos os campos para se cadastrar", Toast.LENGTH_LONG).show();
        } else{
            Usuario u = new Usuario(l, s);
            u.salvabd();
            Toast.makeText(this, "Usuário Cadastrado com Sucesso", Toast.LENGTH_LONG).show();
            Intent z = new Intent(this, MainActivity.class);
            startActivity(z) ;
        }
    }
}