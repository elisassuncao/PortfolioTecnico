package com.example.gameofold;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button b00, b01, b02, b10, b11, b12, b20, b21, b22;
    String ultimo = "O";
    String [][] velhinha = {{"a","b","c"}, {"d","e","f"}, {"g","h","i"}};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        b00 = findViewById(R.id.b00);
        b01 = findViewById(R.id.b01);
        b02 = findViewById(R.id.b02);
        b10 = findViewById(R.id.b10);
        b11 = findViewById(R.id.b11);
        b12 = findViewById(R.id.b12);
        b20 = findViewById(R.id.b20);
        b21 = findViewById(R.id.b21);
        b22 = findViewById(R.id.b22);
    }
    public void define(){
        if(ultimo.equals("O")){
            ultimo = "X";
        }
        else{
            ultimo = "O";
        }
    }
    public void cb00(View v) {
        define();
        velhinha[0][0] = ultimo;
        b00.setText(ultimo);
        b00.setEnabled(false);
        vencedor();
    }
    public void cb01(View v) {
        define();
        velhinha[0][1] = ultimo;
        b01.setText(ultimo);
        b01.setEnabled(false);
        vencedor();
    }
    public void cb02(View v) {
        define();
        velhinha[0][2] = ultimo;
        b02.setText(ultimo);
        b02.setEnabled(false);
        vencedor();
    }
    public void cb10(View v) {
        define();
        velhinha[1][0] = ultimo;
        b10.setText(ultimo);
        b10.setEnabled(false);
        vencedor();
    }
    public void cb11(View v) {
        define();
        velhinha[1][1] = ultimo;
        b11.setText(ultimo);
        b11.setEnabled(false);
        vencedor();
    }
    public void cb12(View v) {
        define();
        velhinha[1][2] = ultimo;
        b12.setText(ultimo);
        b12.setEnabled(false);
        vencedor();
    }
    public void cb20(View v) {
        define();
        velhinha[2][0] = ultimo;
        b20.setText(ultimo);
        b20.setEnabled(false);
        vencedor();
    }
    public void cb21(View v) {
        define();
        velhinha[2][1] = ultimo;
        b21.setText(ultimo);
        b21.setEnabled(false);
        vencedor();
    }
    public void cb22(View v) {
        define();
        velhinha[2][2] = ultimo;
        b22.setText(ultimo);
        b22.setEnabled(false);
        vencedor();
    }

    public void recomeçar(View v){
        b00.setText("");
        b01.setText("");
        b02.setText("");
        b10.setText("");
        b11.setText("");
        b12.setText("");
        b20.setText("");
        b21.setText("");
        b22.setText("");
        b00.setEnabled(true);
        b01.setEnabled(true);
        b02.setEnabled(true);
        b10.setEnabled(true);
        b11.setEnabled(true);
        b12.setEnabled(true);
        b20.setEnabled(true);
        b21.setEnabled(true);
        b22.setEnabled(true);
        ultimo = "";
    }

    public void vencedor(){
        trio(velhinha[0][0],velhinha[0][1],velhinha[0][2]);
        trio(velhinha[1][0],velhinha[1][1],velhinha[1][2]);
        trio(velhinha[2][0],velhinha[2][1],velhinha[2][2]);

        trio(velhinha[0][0],velhinha[1][0],velhinha[2][0]);
        trio(velhinha[0][1],velhinha[1][1],velhinha[2][1]);
        trio(velhinha[0][2],velhinha[1][2],velhinha[2][2]);

        trio(velhinha[0][0],velhinha[1][1],velhinha[2][2]);
        trio(velhinha[0][2],velhinha[1][1],velhinha[2][0]);
    }
    
    public void trio(String s1, String s2, String s3){
        if(s1.equals(s2) && s2.equals(s3)){
            Toast.makeText(this, s2+" Venceu!!!", Toast.LENGTH_LONG).show();
        }
    }
}