package com.example.matrix;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView mat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        mat = findViewById(R.id.matrix);
        criarMatriz();
    }
    public void criarMatriz(){
        /*int[][] numeros = new int[3][3];*/
        String matrix = "matrix\n";
        int[][] numeros = {{1,2,3},{4,5,6},{7,8,9}};
        for(int linha = 0; linha < 3; linha ++){
            for(int coluna = 0; coluna < 3; coluna ++){
                matrix += numeros[linha][coluna]+" ";
            }
            matrix += "\n";
        }

        mat.setText(matrix);
    }
}