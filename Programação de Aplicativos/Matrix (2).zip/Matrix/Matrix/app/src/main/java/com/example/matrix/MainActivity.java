package com.example.matrix;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView mat;
    TextView result;
    EditText n1,n2,n3,n4,n5,n6,n7,n8,n9;
    int[][] numeros = new int[3][3];
    int resultado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        mat = findViewById(R.id.matrix);
        result = findViewById(R.id.result);
        n1 = findViewById(R.id.n1);
        n2 = findViewById(R.id.n2);
        n3 = findViewById(R.id.n3);
        n4 = findViewById(R.id.n4);
        n5 = findViewById(R.id.n5);
        n6 = findViewById(R.id.n6);
        n7 = findViewById(R.id.n7);
        n8 = findViewById(R.id.n8);
        n9 = findViewById(R.id.n9);
        //criarMatriz();
    }
    public void criarMatriz(){
        //int[][] numeros = new int[3][3];
        String matrix = "matrix\n";
        for(int linha = 0; linha < 3; linha ++){
            for(int coluna = 0; coluna < 3; coluna ++){
                matrix += numeros[linha][coluna]+" ";
            }
            matrix += "\n";
        }

        mat.setText(matrix);
    }

    public void calcularMatriz(View v){
        numeros[0][0] = Integer.parseInt(String.valueOf(n1.getText()));
        numeros[0][1] = Integer.parseInt(String.valueOf(n2.getText()));
        numeros[0][2] = Integer.parseInt(String.valueOf(n3.getText()));
        numeros[1][0] = Integer.parseInt(String.valueOf(n4.getText()));
        numeros[1][1] = Integer.parseInt(String.valueOf(n5.getText()));
        numeros[1][2] = Integer.parseInt(String.valueOf(n6.getText()));
        numeros[2][0] = Integer.parseInt(String.valueOf(n7.getText()));
        numeros[2][1] = Integer.parseInt(String.valueOf(n8.getText()));
        numeros[2][2] = Integer.parseInt(String.valueOf(n9.getText()));

         resultado = (
                        (numeros[0][0] * numeros[1][1] * numeros[2][2]) +
                        (numeros[0][1] * numeros[1][2] * numeros[2][0]) +
                        (numeros[0][2] * numeros[1][0] * numeros[2][1]) +
                        (numeros[0][0] * numeros[1][1] * numeros[2][2]) -
                        (numeros[2][0] * numeros[1][1] * numeros[0][2]) -
                        (numeros[2][1] * numeros[1][2] * numeros[0][0]) -
                        (numeros[2][2] * numeros[1][0] * numeros[0][1])
                        );
        String resulta = Integer.toString(resultado);
        result.setText(resulta);
    }

    public void mudaTelaAcertar(View view){

    }


}