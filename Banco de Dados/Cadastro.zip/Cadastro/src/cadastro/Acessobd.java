/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cadastro;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *
 * @author elisa_assuncao
 */
public class Acessobd {
    
     private static Connection connection;
   
    public static Connection getConnection(){
        if(connection == null){
            try{
                //Class.forName("com.mysql.jdbc.Driver"); //para mysql
                 Class.forName("org.postgresql.Driver");//para postgresql
                String host = "localhost";
                String port = "5432";
                String database = "postgres";
                String user = "postgres";
                String pass = "senai";//digitar a senha do seu banco
                //String url = "jdbc:mysql://"+host+":"+port+"/"+database; //para mysql
                String url = "jdbc:postgresql://"+host+":"+port+"/"+database;//para postgresql
                connection = DriverManager.getConnection(url, user, pass);                 
               
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }
    public static void close(){
        if (connection == null){
            throw new RuntimeException("Nenhuma conexão aberta!");
        }
        else{
            try{
                connection.close();
            }
            catch (SQLException e){
                e.printStackTrace();
            }
        }
    }
 
    public static void salvar (Usuario usuario){
        try{
            Connection con = Acessobd.getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO usuario (senha, nome, login) values(?, ?, ?)");
            ps.setString(1, usuario.getSenha());
            ps.setString(2, usuario.getNome());
            ps.setString(3, usuario.getLogin());
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void deleta(String login){
        try{
            Connection con = Acessobd.getConnection();
            PreparedStatement ps = con.prepareStatement("Delete FROM usuario WHERE login = ?");
            ps.setString(1, login);
            ps.executeUpdate();


            }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void atualizaBanco(Usuario usuario){
        deleta(usuario.getLogin());
        salvar(usuario);
    }
    
     public static void mudaSenhaUser(Usuario usuario){
        deleta(usuario.getLogin());
        salvar(usuario);
    }
    
    public static void visualizaTabela(String tabela, String... atributos){
        try{
            Connection con = Acessobd.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM "+tabela);
            ResultSet res = ps.executeQuery();
            String selectfrom =  "  " ;
            while(res.next()){
                for(String i : atributos){
                    selectfrom = selectfrom  +  " - "  +  res.getString(i);
                }
                selectfrom = selectfrom +  "\n";
            }
            System.out.println(selectfrom);
        }
        
        catch(Exception e){
            e.printStackTrace();
        }
    }
}
