/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetofinalbancolivros;

/**
 *
 * @author elisa_assuncao
 */
public class Lidos {
    String cod_lidos;
    String nota;
    String feedback;
    String isbn_lido;

    public Lidos(String cod_lidos, String nota, String feedback, String isbn_lido) {
        this.cod_lidos = cod_lidos;
        this.nota = nota;
        this.feedback = feedback;
        this.isbn_lido = isbn_lido;
    }

    public String getCod_lidos() {
        return cod_lidos;
    }

    public void setCod_lidos(String cod_lido) {
        this.cod_lidos = cod_lido;
    }

    public String getNota() {
        return nota;
    }

    public void setNota(String nota) {
        this.nota = nota;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public String getIsbn_lido() {
        return isbn_lido;
    }

    public void setIsbn_lido(String isbn_lido) {
        this.isbn_lido = isbn_lido;
    }

}
