/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetofinalbancolivros;

/**
 *
 * @author elisa_assuncao
 */
public class Livros {
    String isbn;
    String nome;
    String autor;
    String genero;
    String sinopse;
    String classificacao;
    String qtd_pag;

    public Livros(String isbn, String nome, String autor, String genero, String sinopse, String classificacao, String qtd_pag) {
        this.isbn = isbn;
        this.nome = nome;
        this.autor = autor;
        this.genero = genero;
        this.sinopse = sinopse;
        this.classificacao = classificacao;
        this.qtd_pag = qtd_pag;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getSinopse() {
        return sinopse;
    }

    public void setSinopse(String sinopse) {
        this.sinopse = sinopse;
    }

    public String getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(String classificacao) {
        this.classificacao = classificacao;
    }

    public String getQtd_pag() {
        return qtd_pag;
    }

    public void setQtd_pag(String qtd_pag) {
        this.qtd_pag = qtd_pag;
    }

}
