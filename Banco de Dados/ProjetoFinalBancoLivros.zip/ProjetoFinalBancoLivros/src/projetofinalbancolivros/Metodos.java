/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetofinalbancolivros;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author elisa_assuncao
 */
public class Metodos {
    
    private static Connection connection;
    private static int i;
    private static int ler;
    private static int lido;

    public static Connection getConnection() {
        if (connection == null) {
            try {
                //Class.forName("com.mysql.jdbc.Driver"); //para mysql
                Class.forName("org.postgresql.Driver");//para postgresql
                String host = "localhost";
                String port = "5432";
                String database = "postgres";
                String user = "postgres";
                String pass = "senai";//digitar a senha do seu banco
                //String url = "jdbc:mysql://"+host+":"+port+"/"+database; //para mysql
                String url = "jdbc:postgresql://" + host + ":" + port + "/" + database;//para postgresql
                connection = DriverManager.getConnection(url, user, pass);

            } catch (ClassNotFoundException | SQLException e) {
                 e.printStackTrace();
            }
        }
        return connection;
    }
    public static void close() {
        if (connection == null) {
            throw new RuntimeException("Nenhuma conexão aberta!");
        } else {
            try {
                connection.close();
            } catch (SQLException e) {
                 e.printStackTrace();
            }
        }
    }
    
    public static void salvarLivros(Livros  livros) {
        try {
            Connection con = Metodos.getConnection();
            PreparedStatement ps;
            ps = con.prepareStatement("INSERT INTO livros(isbn, nome, autor, genero, sinopse, classificacao, qtd_pag) values(?, ?, ?, ?, ?, ?, ?)");
            System.out.println(livros.getIsbn());
            System.out.println(livros.getNome());
            System.out.println(livros.getAutor());
            System.out.println(livros.getGenero());
            System.out.println(livros.getSinopse());
            System.out.println(livros.getClassificacao());
            System.out.println(livros.getQtd_pag());
            ps.setString(1, livros.getIsbn());
            ps.setString(2, livros.getNome());
            ps.setString(3, livros.getAutor());
            ps.setString(4, livros.getGenero());
            ps.setString(5, livros.getSinopse());
            ps.setString(6, livros.getClassificacao());
            ps.setString(7, livros.getQtd_pag());
            ps.execute();
        } catch (SQLException e) {
             e.printStackTrace();
        }
    }
    
    public static void excluirLivros(String isbn) {
        try {
            Connection con = Metodos.getConnection();
            PreparedStatement ps = con.prepareStatement("Delete FROM livros WHERE isbn = ?");
            ps.setString(1,isbn);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
        public static String VisualizarTabelaLivros(String... atributos){
        String resultadoLivros = "";
        try{
            Connection con = Metodos.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM livros");
            ResultSet res = ps.executeQuery();
            String selectfrom =  "<html>  " ;
            while(res.next()){
                for(String i : atributos){
                    selectfrom = selectfrom  +  " - "  +  res.getString(i);
                }
                selectfrom = selectfrom +  "<br>";
                resultadoLivros = selectfrom;
            }
            resultadoLivros = resultadoLivros + "<html/>";
            
        }
        
        catch(Exception e){
            e.printStackTrace();
        }
        return resultadoLivros;
        
    }
    
    
    
    public static void salvarLer(Ler ler) {
        try {
            Connection con = Metodos.getConnection();
            PreparedStatement ps;
            ps = con.prepareStatement("INSERT INTO ler(cod_ler, nota_esperada, expectativa, isbn_ler) values(?, ?, ?, ?)");
            System.out.println(ler.getCod_ler());
            System.out.println(ler.getNota_esperada());
            System.out.println(ler.getExpectativa());
            System.out.println(ler.getIsbn_ler());
            ps.setString(1, ler.getCod_ler());
            ps.setString(2, ler.getNota_esperada());
            ps.setString(3, ler.getExpectativa());
            ps.setString(4, ler.getIsbn_ler());
            ps.execute();
        } catch (SQLException e) {
             e.printStackTrace();
        }
    }
    
    public static void excluirLer(String isbn_ler) {
        try {
            Connection con = Metodos.getConnection();
            PreparedStatement ps = con.prepareStatement("Delete FROM ler WHERE cod_ler = ?");
            ps.setString(1, isbn_ler);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static String VisualizarTabelaLer(String... atributos){
        String resultadoLer = "";
        try{
            Connection con = Metodos.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM ler");
            ResultSet res = ps.executeQuery();
            String selectfrom =  "<html>  " ;
            while(res.next()){
                for(String i : atributos){
                    selectfrom = selectfrom  +  " - "  +  res.getString(i);
                }
                selectfrom = selectfrom +  "<br>";
                resultadoLer = selectfrom;
            }
            resultadoLer = resultadoLer + "<html/>";
            
        }
        
        catch(Exception e){
            e.printStackTrace();
        }
        return resultadoLer;
        
    }
    
    
    
    public static void salvarLidos(Lidos lidos) {
        try {
            Connection con = Metodos.getConnection();
            PreparedStatement ps;
            ps = con.prepareStatement("INSERT INTO lidos(cod_lidos, nota, feedback, isbn_lido) values(?, ?, ?, ?)");
            System.out.println(lidos.getCod_lidos());
            System.out.println(lidos.getNota());
            System.out.println(lidos.getFeedback());
            System.out.println(lidos.getIsbn_lido());
            ps.setString(1, lidos.getCod_lidos());
            ps.setString(2, lidos.getNota());
            ps.setString(3, lidos.getFeedback());
            ps.setString(4, lidos.getIsbn_lido());
            ps.execute();
        } catch (SQLException e) {
             e.printStackTrace();
        }
    }
    
    public static void excluirLidos(String isbn_lido) {
        try {
            Connection con = Metodos.getConnection();
            PreparedStatement ps = con.prepareStatement("Delete FROM lidos WHERE cod_lidos = ?");
            ps.setString(1, isbn_lido);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
        public static String VisualizarTabelaLidos(String... atributos){
        String resultadoLidos = "";
        try{
            Connection con = Metodos.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM lidos");
            ResultSet res = ps.executeQuery();
            String selectfrom =  "<html>  " ;
            while(res.next()){
                for(String i : atributos){
                    selectfrom = selectfrom  +  " - "  +  res.getString(i);
                }
                selectfrom = selectfrom +  "<br>";
                resultadoLidos = selectfrom;
            }
            resultadoLidos = resultadoLidos + "<html/>";
            
        }
        
        catch(Exception e){
            e.printStackTrace();
        }
        return resultadoLidos;
        
    }
   

    
}
