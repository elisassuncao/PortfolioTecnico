/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetofinalbancolivros;


/**
 *
 * @author elisa_assuncao
 */
public class ProjetoFinalBancoLivros {
    
   

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Livros l = new Livros("isbn", "livro", "autor", "genero", "sinopse", "classi", "pags");
        //Metodos.salvarLivros(l);
        TelaInicio ti = new TelaInicio();
        ti.setVisible(true);
        
        //Ler le = new Ler("cod_ler", "nota_esperada", "expectativa", "isbn");
        //Metodos.excluirLer(le);
        //Metodos.excluirLer("isbn");
        
        
        //Lidos li = new Lidos("cod_lidos", "nota", "feedback", "isbn");
        //Metodos.salvarLidos(li);
        //Metodos.excluirLidos("isbn");
        
        
    }
    
    
    }
  
    
